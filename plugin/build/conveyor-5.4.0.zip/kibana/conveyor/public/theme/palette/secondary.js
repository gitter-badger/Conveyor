export default {
    50: '#effcff',
    100: '#d8f7fe',
    200: '#bef2fd',
    300: '#a3ecfc',
    400: '#90e8fc',
    500: '#7ce4fb',
    600: '#74e1fa',
    700: '#69ddfa',
    800: '#5fd9f9',
    900: '#4cd1f8',
    A100: '#ffffff',
    A200: '#ffffff',
    A400: '#ebfaff',
    A700: '#d2f4ff',
    'contrastDefaultColor': 'light'
};