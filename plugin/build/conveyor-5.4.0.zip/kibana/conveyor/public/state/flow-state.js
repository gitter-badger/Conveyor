export class FlowState {
    constructor() {
        this.flows = [];
        this.selectedSource = null;
    }
}